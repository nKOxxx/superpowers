# /ship - Release Pipeline

One-command release pipeline with semantic versioning.

## Usage

```bash
superpowers ship [options]
```

## Options

- `--version, -v` - Version bump: patch (default), minor, major, or explicit version
- `--dry-run, -d` - Preview changes without applying
- `--skip-github` - Skip GitHub release creation

## Environment Variables

- `GH_TOKEN` or `GITHUB_TOKEN` - Required for GitHub release creation

## Examples

```bash
# Patch release
superpowers ship

# Minor release with preview
superpowers ship --version=minor --dry-run

# Explicit version
superpowers ship --version=2.0.0

# Release without GitHub
superpowers ship --skip-github
```

## Features

- Semantic versioning (patch/minor/major)
- Conventional commit changelog generation
- Git tag creation and push
- GitHub release creation
- Package.json version bumping
