export interface ShipOptions {
    bump?: 'patch' | 'minor' | 'major';
    dryRun?: boolean;
    skipChangelog?: boolean;
    skipGit?: boolean;
    skipGithub?: boolean;
    message?: string;
    prerelease?: string;
}
export interface VersionInfo {
    current: string;
    next: string;
}
export interface ShipResult {
    success: boolean;
    version: VersionInfo;
    steps: StepResult[];
    error?: string;
}
export interface StepResult {
    name: string;
    success: boolean;
    output?: string;
    error?: string;
}
export declare function shipCommand(options?: ShipOptions): Promise<ShipResult>;
//# sourceMappingURL=index.d.ts.map