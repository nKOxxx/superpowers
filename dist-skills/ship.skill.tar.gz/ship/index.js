"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShipSkill = void 0;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs/promises"));
const semver = __importStar(require("semver"));
class ShipSkill {
    async ship(options) {
        // Validate working directory
        this.validateGitRepo();
        if (!options.dryRun) {
            this.validateCleanWorkingDirectory();
        }
        // Get current version
        const currentVersion = await this.getCurrentVersion();
        // Calculate new version
        const newVersion = this.calculateVersion(currentVersion, options.version);
        const tag = `v${newVersion}`;
        // Run tests if not skipped
        if (!options.skipTests && !options.dryRun) {
            this.runTests();
        }
        // Generate changelog
        const commits = this.getCommitsSinceLastTag();
        const changelog = this.generateChangelog(commits, newVersion);
        if (options.dryRun) {
            console.log('DRY RUN - Would execute:');
            console.log(`  - Update version: ${currentVersion} → ${newVersion}`);
            console.log(`  - Update CHANGELOG.md`);
            console.log(`  - Commit: "chore: release ${newVersion}"`);
            console.log(`  - Tag: ${tag}`);
            console.log(`  - Push to origin`);
            if (process.env.GH_TOKEN) {
                console.log(`  - Create GitHub release`);
            }
            return {
                version: newVersion,
                tag,
                commits,
                changelog,
                pushed: false,
                released: false
            };
        }
        // Update package.json
        await this.updateVersion(newVersion);
        // Update changelog
        await this.updateChangelog(changelog);
        // Create commit and tag
        this.createCommit(newVersion);
        this.createTag(tag);
        // Push
        this.pushToOrigin(tag);
        // Create GitHub release
        let released = false;
        if (process.env.GH_TOKEN) {
            released = await this.createGitHubRelease(options, tag, changelog);
        }
        return {
            version: newVersion,
            tag,
            commits,
            changelog,
            pushed: true,
            released
        };
    }
    validateGitRepo() {
        try {
            (0, child_process_1.execSync)('git rev-parse --git-dir', { stdio: 'ignore' });
        }
        catch {
            throw new Error('Not a git repository');
        }
    }
    validateCleanWorkingDirectory() {
        try {
            const status = (0, child_process_1.execSync)('git status --porcelain', { encoding: 'utf-8' });
            if (status.trim()) {
                throw new Error('Working directory is not clean. Please commit or stash changes first.');
            }
        }
        catch (error) {
            if (error.message.includes('not clean'))
                throw error;
            throw new Error('Failed to check git status');
        }
    }
    async getCurrentVersion() {
        try {
            const pkg = JSON.parse(await fs.readFile('package.json', 'utf-8'));
            return pkg.version || '0.0.0';
        }
        catch {
            return '0.0.0';
        }
    }
    calculateVersion(current, bump) {
        if (semver.valid(bump)) {
            return bump;
        }
        if (['patch', 'minor', 'major'].includes(bump)) {
            const newVersion = semver.inc(current, bump);
            if (newVersion)
                return newVersion;
        }
        throw new Error(`Invalid version bump: ${bump}. Use patch, minor, major, or explicit version.`);
    }
    runTests() {
        console.log('Running tests...');
        try {
            (0, child_process_1.execSync)('npm test', { stdio: 'inherit' });
        }
        catch {
            throw new Error('Tests failed. Release aborted.');
        }
    }
    getCommitsSinceLastTag() {
        try {
            const lastTag = (0, child_process_1.execSync)('git describe --tags --abbrev=0 2>/dev/null || echo ""', {
                encoding: 'utf-8'
            }).trim();
            const range = lastTag ? `${lastTag}..HEAD` : 'HEAD';
            const output = (0, child_process_1.execSync)(`git log ${range} --pretty=format:"%s"`, { encoding: 'utf-8' });
            return output.trim().split('\n').filter(c => c);
        }
        catch {
            return [];
        }
    }
    generateChangelog(commits, version) {
        const categories = {
            Features: [],
            'Bug Fixes': [],
            Chores: [],
            Other: []
        };
        for (const commit of commits) {
            if (commit.startsWith('feat:') || commit.startsWith('feat(')) {
                categories.Features.push(commit);
            }
            else if (commit.startsWith('fix:') || commit.startsWith('fix(')) {
                categories['Bug Fixes'].push(commit);
            }
            else if (commit.startsWith('chore:') || commit.startsWith('chore(')) {
                categories.Chores.push(commit);
            }
            else {
                categories.Other.push(commit);
            }
        }
        let changelog = `## [${version}] - ${new Date().toISOString().split('T')[0]}\n\n`;
        for (const [category, items] of Object.entries(categories)) {
            if (items.length > 0) {
                changelog += `### ${category}\n`;
                for (const item of items) {
                    changelog += `- ${item}\n`;
                }
                changelog += '\n';
            }
        }
        return changelog;
    }
    async updateVersion(version) {
        const pkg = JSON.parse(await fs.readFile('package.json', 'utf-8'));
        pkg.version = version;
        await fs.writeFile('package.json', JSON.stringify(pkg, null, 2) + '\n');
    }
    async updateChangelog(changelog) {
        const changelogPath = 'CHANGELOG.md';
        let existing = '';
        try {
            existing = await fs.readFile(changelogPath, 'utf-8');
        }
        catch { }
        const header = '# Changelog\n\nAll notable changes to this project will be documented in this file.\n\n';
        const newContent = header + changelog + existing.replace(header, '');
        await fs.writeFile(changelogPath, newContent);
    }
    createCommit(version) {
        (0, child_process_1.execSync)('git add package.json CHANGELOG.md', { stdio: 'ignore' });
        (0, child_process_1.execSync)(`git commit -m "chore: release ${version}"`, { stdio: 'ignore' });
    }
    createTag(tag) {
        (0, child_process_1.execSync)(`git tag ${tag}`, { stdio: 'ignore' });
    }
    pushToOrigin(tag) {
        (0, child_process_1.execSync)('git push origin HEAD', { stdio: 'ignore' });
        (0, child_process_1.execSync)(`git push origin ${tag}`, { stdio: 'ignore' });
    }
    async createGitHubRelease(options, tag, changelog) {
        if (!process.env.GH_TOKEN)
            return false;
        try {
            const repo = options.repo || this.detectRepo();
            if (!repo) {
                console.warn('Could not detect repository for GitHub release');
                return false;
            }
            const releaseNotes = options.notes ? `${options.notes}\n\n${changelog}` : changelog;
            (0, child_process_1.execSync)(`gh release create ${tag} \
          --repo ${repo} \
          --title "${tag}" \
          --notes "${releaseNotes.replace(/"/g, '\\"')}" \
          ${options.prerelease ? '--prerelease' : ''}`, { stdio: 'ignore' });
            return true;
        }
        catch (error) {
            console.warn('Failed to create GitHub release:', error);
            return false;
        }
    }
    detectRepo() {
        try {
            const remote = (0, child_process_1.execSync)('git remote get-url origin', { encoding: 'utf-8' }).trim();
            // Parse GitHub URL
            const match = remote.match(/github\.com[:/]([^/]+)\/([^/]+)(\.git)?$/);
            if (match) {
                return `${match[1]}/${match[2].replace(/\.git$/, '')}`;
            }
        }
        catch { }
        return null;
    }
}
exports.ShipSkill = ShipSkill;
exports.default = ShipSkill;
//# sourceMappingURL=index.js.map