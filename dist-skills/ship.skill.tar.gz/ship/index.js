"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const commander_1 = require("commander");
const chalk_1 = __importDefault(require("chalk"));
const ora_1 = __importDefault(require("ora"));
const child_process_1 = require("child_process");
const fs_1 = require("fs");
const path_1 = require("path");
function exec(cmd, cwd = process.cwd()) {
    try {
        return (0, child_process_1.execSync)(cmd, { encoding: 'utf-8', cwd, stdio: 'pipe' }).trim();
    }
    catch (e) {
        throw new Error(`Command failed: ${cmd}\n${e.stderr || e.message}`);
    }
}
function getVersion() {
    const pkg = JSON.parse((0, fs_1.readFileSync)((0, path_1.join)(process.cwd(), 'package.json'), 'utf-8'));
    return pkg.version || '0.0.0';
}
function bump(v, type) {
    const [major, minor, patch] = v.split('.').map(Number);
    if (type === 'major')
        return `${major + 1}.0.0`;
    if (type === 'minor')
        return `${major}.${minor + 1}.0`;
    return `${major}.${minor}.${patch + 1}`;
}
function getCommits() {
    try {
        const lastTag = exec('git describe --tags --abbrev=0 2>/dev/null || echo ""');
        const range = lastTag ? `${lastTag}..HEAD` : 'HEAD';
        return exec(`git log ${range} --pretty=format:"%s"`).split('\n').filter(Boolean);
    }
    catch {
        return [];
    }
}
function changelogEntry(version, commits) {
    const date = new Date().toISOString().split('T')[0];
    const features = commits.filter(c => c.startsWith('feat')).map(c => c.replace(/^feat(?:\(.+\))?: /, ''));
    const fixes = commits.filter(c => c.startsWith('fix')).map(c => c.replace(/^fix(?:\(.+\))?: /, ''));
    let entry = `## [${version}] - ${date}\n\n`;
    if (features.length) {
        entry += '### Features\n';
        features.forEach(f => entry += `- ${f}\n`);
        entry += '\n';
    }
    if (fixes.length) {
        entry += '### Fixes\n';
        fixes.forEach(f => entry += `- ${f}\n`);
        entry += '\n';
    }
    return entry;
}
function updateChangelog(entry) {
    const path = (0, path_1.join)(process.cwd(), 'CHANGELOG.md');
    const header = '# Changelog\n\n';
    const existing = (0, fs_1.existsSync)(path) ? (0, fs_1.readFileSync)(path, 'utf-8').replace(header, '') : '';
    (0, fs_1.writeFileSync)(path, header + entry + existing);
}
async function ship(versionType, dryRun, skipChangelog, skipGit, skipGithub) {
    const spinner = (0, ora_1.default)('Preparing release...').start();
    try {
        const status = exec('git status --porcelain');
        if (status && !dryRun) {
            spinner.fail('Working directory not clean');
            process.exit(1);
        }
        const current = getVersion();
        const newVersion = ['patch', 'minor', 'major'].includes(versionType) ? bump(current, versionType) : versionType;
        spinner.text = `${current} → ${newVersion}`;
        const commits = getCommits();
        if (!skipChangelog) {
            const entry = changelogEntry(newVersion, commits);
            if (dryRun)
                console.log('\nChangelog:\n' + entry);
            else
                updateChangelog(entry);
        }
        if (!dryRun) {
            const pkg = JSON.parse((0, fs_1.readFileSync)((0, path_1.join)(process.cwd(), 'package.json'), 'utf-8'));
            pkg.version = newVersion;
            (0, fs_1.writeFileSync)((0, path_1.join)(process.cwd(), 'package.json'), JSON.stringify(pkg, null, 2) + '\n');
        }
        if (!skipGit && !dryRun) {
            exec('git add -A');
            exec(`git commit -m "chore(release): ${newVersion}"`);
            exec(`git tag -a v${newVersion} -m "Release v${newVersion}"`);
            exec('git push && git push --tags');
        }
        if (!skipGithub && !dryRun) {
            try {
                exec(`gh release create v${newVersion} --title "v${newVersion}" --notes "Release ${newVersion}"`);
            }
            catch {
                spinner.warn('GitHub release failed');
            }
        }
        spinner.succeed(dryRun ? chalk_1.default.yellow('Dry run complete') : chalk_1.default.green(`Released v${newVersion}!`));
    }
    catch (e) {
        spinner.fail(String(e));
        process.exit(1);
    }
}
const program = new commander_1.Command();
program.name('ship').description('Release pipeline').version('1.0.0');
program.argument('[version]', 'Version type or explicit version', 'patch')
    .option('-d, --dry-run', 'Preview only').option('--skip-changelog', 'Skip changelog')
    .option('--skip-git', 'Skip git').option('--skip-github', 'Skip GitHub')
    .action((v, opts) => ship(v, opts.dryRun, opts.skipChangelog, opts.skipGit, opts.skipGithub));
program.command('preview').action(() => {
    const commits = getCommits();
    console.log(chalk_1.default.cyan(`Commits since last tag: ${commits.length}`));
    commits.forEach(c => console.log(`  - ${c}`));
});
program.command('version').action(() => console.log(getVersion()));
program.parse();
//# sourceMappingURL=index.js.map