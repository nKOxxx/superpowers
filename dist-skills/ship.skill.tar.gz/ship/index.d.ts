interface ShipOptions {
    version: string;
    repo?: string;
    dryRun: boolean;
    skipTests: boolean;
    notes?: string;
    prerelease: boolean;
}
export declare function run(options: ShipOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map