export interface ShipOptions {
    version: string;
    repo?: string;
    dryRun?: boolean;
    skipTests?: boolean;
    notes?: string;
    prerelease?: boolean;
}
export interface ReleaseResult {
    version: string;
    tag: string;
    commits: string[];
    changelog: string;
    pushed: boolean;
    released: boolean;
}
export declare class ShipSkill {
    ship(options: ShipOptions): Promise<ReleaseResult>;
    private validateGitRepo;
    private validateCleanWorkingDirectory;
    private getCurrentVersion;
    private calculateVersion;
    private runTests;
    private getCommitsSinceLastTag;
    private generateChangelog;
    private updateVersion;
    private updateChangelog;
    private createCommit;
    private createTag;
    private pushToOrigin;
    private createGitHubRelease;
    private detectRepo;
}
export default ShipSkill;
//# sourceMappingURL=index.d.ts.map