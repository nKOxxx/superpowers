# /plan-ceo-review - Product Strategy (BAT Framework)

Product strategy review using BAT (Brand, Attention, Trust) framework.

## Usage

```bash
superpowers ceo-review --feature="Name" [options]
```

## Options

- `--feature` (required) - Feature name to review
- `--brand` - Brand score (0-5)
- `--attention` - Attention score (0-5)
- `--trust` - Trust score (0-5)
- `--goal` - Feature goal/strategy context
- `--auto` - Auto-calculate scores
- `--output, -o` - Save report to file

## 10-Star Methodology

- **BUILD** (10-15 stars): Strong alignment, prioritize
- **CONSIDER** (6-9 stars): Meets minimum threshold, needs refinement
- **DON'T BUILD** (0-5 stars): Below threshold, deprioritize

Minimum: 6 total stars with at least 2/3 categories at 2+

## Examples

```bash
# Auto-score a feature
superpowers ceo-review --feature="AI Chat Assistant" --auto

# Manual scoring
superpowers ceo-review --feature="Dark Mode" --brand=4 --attention=3 --trust=4

# With goal and output
superpowers ceo-review --feature="Social Share" --goal="Increase viral growth" --output=review.md
```

## Scoring Guide

### Brand (0-5)
- 0-1: No brand impact
- 2-3: Moderate brand alignment
- 4-5: Strong brand differentiator

### Attention (0-5)
- 0-1: Low user engagement
- 2-3: Moderate engagement potential
- 4-5: High virality/engagement

### Trust (0-5)
- 0-1: Potential trust risk
- 2-3: Neutral or standard
- 4-5: Builds significant trust
