/**
 * Review options
 */
export interface ReviewOptions {
    brand?: number;
    attention?: number;
    trust?: number;
    auto: boolean;
    json: boolean;
}
/**
 * BAT Scores
 */
export interface BATScores {
    brand: number;
    attention: number;
    trust: number;
}
/**
 * Review result
 */
export interface ReviewResult {
    name: string;
    description: string;
    scores: BATScores;
    total: number;
    threshold: number;
    passed: boolean;
    stars: number;
    recommendation: 'build' | 'consider' | 'dont-build';
    reasoning: string;
    nextSteps: string[];
    dimensionAnalysis: DimensionAnalysis[];
}
/**
 * Dimension analysis
 */
export interface DimensionAnalysis {
    name: string;
    score: number;
    maxScore: number;
    emoji: string;
    assessment: string;
    suggestions: string[];
}
/**
 * Main review command
 */
export declare function reviewCommand(description: string, options: ReviewOptions): Promise<void>;
declare function parseDescription(description: string): {
    name: string;
    desc: string;
};
declare function clampScore(score: number): number;
declare function autoCalculateScores(name: string, description: string): BATScores;
export { autoCalculateScores, clampScore, parseDescription };
//# sourceMappingURL=index.d.ts.map