interface BATScore {
    brand: number;
    attention: number;
    trust: number;
    total: number;
}
interface TenStarRating {
    problemClarity: number;
    solutionFit: number;
    marketSize: number;
    timing: number;
    teamFit: number;
    monetization: number;
    competition: number;
    distribution: number;
    sustainability: number;
    vision: number;
    total: number;
    average: number;
}
interface CEORReview {
    feature: string;
    goal: string;
    batScore: BATScore;
    tenStar: TenStarRating;
    recommendation: 'build' | 'consider' | 'dont-build';
    reasoning: string[];
    nextSteps: string[];
    risks: string[];
    opportunities: string[];
}
interface ReviewInput {
    feature: string;
    goal: string;
    context?: string;
    marketSize?: 'small' | 'medium' | 'large';
    urgency?: 'low' | 'medium' | 'high';
    resources?: 'limited' | 'moderate' | 'abundant';
}
declare function calculateBATScore(input: ReviewInput): BATScore;
declare function calculateTenStar(input: ReviewInput): TenStarRating;
declare function determineRecommendation(batScore: BATScore, tenStar: TenStarRating): 'build' | 'consider' | 'dont-build';
declare function runCEOReview(input: ReviewInput, options: {
    output?: string;
    json?: boolean;
}): Promise<void>;
export { runCEOReview, calculateBATScore, calculateTenStar, determineRecommendation };
export type { BATScore, TenStarRating, CEORReview, ReviewInput };
//# sourceMappingURL=index.d.ts.map