export interface CEOReviewOptions {
    feature: string;
    goal?: string;
    audience?: string;
    competition?: string;
    trust?: string;
    brand?: number;
    attention?: number;
    trustScore?: number;
}
export interface BATScores {
    brand: number;
    attention: number;
    trust: number;
    total: number;
}
export interface CEOReviewResult {
    feature: string;
    scores: BATScores;
    recommendation: 'BUILD' | 'CONSIDER' | 'DON\'T BUILD';
    rationale: string[];
    nextSteps: string[];
}
export declare class PlanCEOReviewSkill {
    review(options: CEOReviewOptions): CEOReviewResult;
    private calculateScores;
    private autoScoreBrand;
    private autoScoreAttention;
    private autoScoreTrust;
    private getRecommendation;
    private generateRationale;
    private generateNextSteps;
    formatOutput(result: CEOReviewResult): string;
}
export default PlanCEOReviewSkill;
//# sourceMappingURL=index.d.ts.map