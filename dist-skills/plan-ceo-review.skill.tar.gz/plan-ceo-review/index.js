"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runCEOReview = runCEOReview;
exports.calculateBATScore = calculateBATScore;
exports.calculateTenStar = calculateTenStar;
exports.determineRecommendation = determineRecommendation;
const commander_1 = require("commander");
const chalk_1 = __importDefault(require("chalk"));
const ora_1 = __importDefault(require("ora"));
const fs_1 = require("fs");
const BAT_DESCRIPTIONS = {
    brand: {
        name: 'Brand Alignment',
        description: 'How well does this feature align with our brand identity and values?',
        criteria: ['0-1: Misaligned or hurts brand', '2: Neutral, no brand impact', '3: Somewhat aligned', '4: Strongly aligned', '5: Core to brand identity']
    },
    attention: {
        name: 'Attention Capture',
        description: 'Will this feature capture and hold user attention?',
        criteria: ['0-1: Ignored by users', '2: Brief notice only', '3: Moderate engagement', '4: High engagement expected', '5: Viral/habit-forming potential']
    },
    trust: {
        name: 'Trust Building',
        description: 'Does this build or maintain user trust?',
        criteria: ['0-1: Erodes trust significantly', '2: Slightly negative', '3: Neutral', '4: Builds trust', '5: Major trust builder']
    }
};
const TEN_STAR_DESCRIPTIONS = {
    problemClarity: 'How clear and well-defined is the problem?',
    solutionFit: 'How well does the solution fit the problem?',
    marketSize: 'Size of the addressable market (1=niche, 10=massive)',
    timing: 'Is the timing right for this feature?',
    teamFit: 'Does our team have the skills to execute?',
    monetization: 'Clear path to revenue or value?',
    competition: 'Competitive landscape (10=uncontested)',
    distribution: 'Clear path to reach users?',
    sustainability: 'Long-term viability and maintenance?',
    vision: 'Alignment with long-term vision'
};
function calculateBATScore(input) {
    let brand = 3;
    let attention = 3;
    let trust = 3;
    if (input.urgency === 'high')
        attention += 1;
    if (input.resources === 'abundant') {
        brand += 1;
        trust += 1;
    }
    if (input.marketSize === 'large')
        attention += 1;
    else if (input.marketSize === 'small')
        attention -= 1;
    brand = Math.max(0, Math.min(5, brand));
    attention = Math.max(0, Math.min(5, attention));
    trust = Math.max(0, Math.min(5, trust));
    return { brand, attention, trust, total: brand + attention + trust };
}
function calculateTenStar(input) {
    const ratings = {};
    ratings.problemClarity = input.goal.length > 20 ? 7 : 5;
    ratings.solutionFit = 6;
    ratings.marketSize = input.marketSize === 'large' ? 8 : input.marketSize === 'medium' ? 6 : 4;
    ratings.timing = input.urgency === 'high' ? 8 : input.urgency === 'medium' ? 6 : 4;
    ratings.teamFit = input.resources === 'abundant' ? 8 : input.resources === 'moderate' ? 6 : 4;
    ratings.monetization = 5;
    ratings.competition = 5;
    ratings.distribution = 5;
    ratings.sustainability = 6;
    ratings.vision = 7;
    if (input.feature.toLowerCase().includes('ai') || input.feature.toLowerCase().includes('ml')) {
        ratings.timing = Math.min(10, (ratings.timing || 0) + 1);
    }
    if (input.feature.toLowerCase().includes('mobile') || input.feature.toLowerCase().includes('app')) {
        ratings.marketSize = Math.min(10, (ratings.marketSize || 0) + 1);
    }
    const values = Object.values(ratings);
    const total = values.reduce((a, b) => a + b, 0);
    const average = total / values.length;
    return { ...ratings, total, average };
}
function determineRecommendation(batScore, tenStar) {
    const batThreshold = 12;
    const tenStarThreshold = 7.0;
    if (batScore.total >= batThreshold && tenStar.average >= tenStarThreshold)
        return 'build';
    else if (batScore.total >= 8 && tenStar.average >= 5.0)
        return 'consider';
    return 'dont-build';
}
function generateReasoning(_input, batScore, tenStar) {
    const reasoning = [];
    if (batScore.brand >= 4)
        reasoning.push('Strong brand alignment creates competitive moat');
    else if (batScore.brand <= 2)
        reasoning.push('Potential brand dilution risk');
    if (batScore.attention >= 4)
        reasoning.push('High attention capture drives user engagement');
    if (batScore.trust >= 4)
        reasoning.push('Trust-building enhances long-term retention');
    if (tenStar.marketSize >= 8)
        reasoning.push('Large addressable market provides growth runway');
    if (tenStar.timing >= 8)
        reasoning.push('Strong timing advantage in current market');
    if (tenStar.teamFit >= 8)
        reasoning.push('Team capabilities align well with execution requirements');
    if (tenStar.vision >= 8)
        reasoning.push('Strong strategic fit with long-term vision');
    return reasoning;
}
function generateNextSteps(recommendation) {
    const steps = [];
    switch (recommendation) {
        case 'build':
            steps.push('Create detailed product requirements document');
            steps.push('Define success metrics and KPIs');
            steps.push('Allocate development resources');
            steps.push('Set up user feedback loops');
            steps.push('Plan phased rollout strategy');
            break;
        case 'consider':
            steps.push('Conduct user research to validate assumptions');
            steps.push('Build proof-of-concept or prototype');
            steps.push('Analyze competitive landscape more deeply');
            steps.push('Revisit resource requirements');
            steps.push('Define clear go/no-go decision criteria');
            break;
        case 'dont-build':
            steps.push('Document rationale for future reference');
            steps.push('Identify alternative approaches');
            steps.push('Revisit if market conditions change');
            steps.push('Consider as inspiration for related features');
            break;
    }
    return steps;
}
function generateRisks(_input, tenStar) {
    const risks = [];
    if (tenStar.competition <= 4)
        risks.push('High competitive pressure may limit differentiation');
    if (tenStar.teamFit <= 4)
        risks.push('Team capability gaps may require hiring or training');
    if (tenStar.timing <= 4)
        risks.push('Timing may not be optimal for market entry');
    risks.push('Scope creep could delay delivery');
    risks.push('User adoption may be slower than projected');
    return risks;
}
function generateOpportunities(_input, tenStar) {
    const opportunities = [];
    if (tenStar.vision >= 7)
        opportunities.push('Positions company for long-term strategic goals');
    if (tenStar.monetization >= 7)
        opportunities.push('Clear path to revenue generation');
    opportunities.push('Feature could become platform differentiator');
    opportunities.push('May open new partnership or integration opportunities');
    return opportunities;
}
function renderScore(score, max) {
    const filled = Math.round((score / max) * 5);
    const empty = 5 - filled;
    const bar = '█'.repeat(filled) + '░'.repeat(empty);
    return chalk_1.default.gray('[') + bar + chalk_1.default.gray(']');
}
function renderVerdict(passed) {
    return passed ? chalk_1.default.green('✓') : chalk_1.default.red('✗');
}
async function runCEOReview(input, options) {
    const spinner = (0, ora_1.default)('Analyzing feature with CEO framework...').start();
    try {
        const batScore = calculateBATScore(input);
        const tenStar = calculateTenStar(input);
        const recommendation = determineRecommendation(batScore, tenStar);
        const reasoning = generateReasoning(input, batScore, tenStar);
        const nextSteps = generateNextSteps(recommendation);
        const risks = generateRisks(input, tenStar);
        const opportunities = generateOpportunities(input, tenStar);
        const review = {
            feature: input.feature,
            goal: input.goal,
            batScore,
            tenStar,
            recommendation,
            reasoning,
            nextSteps,
            risks,
            opportunities
        };
        spinner.succeed('CEO Review complete');
        if (options.json) {
            console.log(JSON.stringify(review, null, 2));
            if (options.output) {
                (0, fs_1.writeFileSync)(options.output, JSON.stringify(review, null, 2));
                console.log(chalk_1.default.gray(`\nSaved to: ${options.output}`));
            }
            return;
        }
        console.log('\n' + chalk_1.default.cyan('═'.repeat(70)));
        console.log(chalk_1.default.bold('  🎯 CEO REVIEW: PRODUCT STRATEGY ANALYSIS'));
        console.log(chalk_1.default.cyan('═'.repeat(70)));
        console.log(`\n  ${chalk_1.default.bold('Feature:')} ${input.feature}`);
        console.log(`  ${chalk_1.default.bold('Goal:')} ${input.goal}`);
        console.log('\n' + chalk_1.default.yellow('  📊 BAT FRAMEWORK SCORES (0-5 each)'));
        console.log('  ' + '─'.repeat(50));
        console.log(`  ${chalk_1.default.bold('Brand Alignment:')}   ${renderScore(batScore.brand, 5)} ${batScore.brand}/5`);
        console.log(`  ${chalk_1.default.bold('Attention Capture:')}  ${renderScore(batScore.attention, 5)} ${batScore.attention}/5`);
        console.log(`  ${chalk_1.default.bold('Trust Building:')}    ${renderScore(batScore.trust, 5)} ${batScore.trust}/5`);
        console.log('  ' + '─'.repeat(50));
        console.log(`  ${chalk_1.default.bold('BAT Total:')}          ${chalk_1.default.cyan(batScore.total)}/15 ${renderVerdict(batScore.total >= 12)}`);
        console.log('\n' + chalk_1.default.yellow('  ⭐ 10-STAR METHODOLOGY'));
        console.log('  ' + '─'.repeat(50));
        console.log(`  ${'Problem Clarity:'.padEnd(18)} ${renderScore(tenStar.problemClarity, 10)} ${tenStar.problemClarity}/10`);
        console.log(`  ${'Solution Fit:'.padEnd(18)} ${renderScore(tenStar.solutionFit, 10)} ${tenStar.solutionFit}/10`);
        console.log(`  ${'Market Size:'.padEnd(18)} ${renderScore(tenStar.marketSize, 10)} ${tenStar.marketSize}/10`);
        console.log(`  ${'Timing:'.padEnd(18)} ${renderScore(tenStar.timing, 10)} ${tenStar.timing}/10`);
        console.log(`  ${'Team Fit:'.padEnd(18)} ${renderScore(tenStar.teamFit, 10)} ${tenStar.teamFit}/10`);
        console.log(`  ${'Monetization:'.padEnd(18)} ${renderScore(tenStar.monetization, 10)} ${tenStar.monetization}/10`);
        console.log(`  ${'Competition:'.padEnd(18)} ${renderScore(tenStar.competition, 10)} ${tenStar.competition}/10`);
        console.log(`  ${'Distribution:'.padEnd(18)} ${renderScore(tenStar.distribution, 10)} ${tenStar.distribution}/10`);
        console.log(`  ${'Sustainability:'.padEnd(18)} ${renderScore(tenStar.sustainability, 10)} ${tenStar.sustainability}/10`);
        console.log(`  ${'Vision Alignment:'.padEnd(18)} ${renderScore(tenStar.vision, 10)} ${tenStar.vision}/10`);
        console.log('  ' + '─'.repeat(50));
        console.log(`  ${chalk_1.default.bold('Average:')}           ${chalk_1.default.cyan(tenStar.average.toFixed(1))}/10 ${renderVerdict(tenStar.average >= 7)}`);
        console.log(`  ${chalk_1.default.bold('Total:')}             ${chalk_1.default.cyan(tenStar.total)}/100`);
        console.log('\n' + chalk_1.default.yellow('  🎯 RECOMMENDATION'));
        console.log('  ' + '─'.repeat(50));
        const recColor = recommendation === 'build' ? 'green' : recommendation === 'consider' ? 'yellow' : 'red';
        const recEmoji = recommendation === 'build' ? '✅' : recommendation === 'consider' ? '⚠️' : '❌';
        const recText = recommendation === 'build' ? 'BUILD' : recommendation === 'consider' ? 'CONSIDER' : "DON'T BUILD";
        console.log(`  ${recEmoji} ${chalk_1.default[recColor].bold(recText)}`);
        console.log('\n' + chalk_1.default.yellow('  💡 KEY REASONING'));
        reasoning.forEach(r => console.log(`  • ${r}`));
        console.log('\n' + chalk_1.default.green('  🚀 OPPORTUNITIES'));
        opportunities.forEach(o => console.log(`  • ${o}`));
        console.log('\n' + chalk_1.default.red('  ⚠️  RISKS'));
        risks.forEach(r => console.log(`  • ${r}`));
        console.log('\n' + chalk_1.default.cyan('  📋 NEXT STEPS'));
        nextSteps.forEach((step, i) => console.log(`  ${i + 1}. ${step}`));
        console.log('\n' + chalk_1.default.cyan('═'.repeat(70)) + '\n');
        if (options.output) {
            (0, fs_1.writeFileSync)(options.output, JSON.stringify(review, null, 2));
            console.log(chalk_1.default.gray(`Saved review to: ${options.output}\n`));
        }
    }
    catch (error) {
        spinner.fail(chalk_1.default.red(`Review failed: ${error instanceof Error ? error.message : 'Unknown error'}`));
        process.exit(1);
    }
}
function showFrameworks() {
    console.log(chalk_1.default.cyan('\n╔════════════════════════════════════════════════════════════════════╗'));
    console.log(chalk_1.default.cyan('║         BAT FRAMEWORK - Strategic Decision Making                  ║'));
    console.log(chalk_1.default.cyan('╚════════════════════════════════════════════════════════════════════╝\n'));
    for (const [, desc] of Object.entries(BAT_DESCRIPTIONS)) {
        console.log(chalk_1.default.yellow(`${desc.name.toUpperCase()}`));
        console.log(chalk_1.default.gray(`  ${desc.description}`));
        console.log(chalk_1.default.gray('  Scoring:'));
        for (const criterion of desc.criteria)
            console.log(chalk_1.default.gray(`    ${criterion}`));
        console.log('');
    }
    console.log(chalk_1.default.cyan('╔════════════════════════════════════════════════════════════════════╗'));
    console.log(chalk_1.default.cyan('║         10-STAR METHODOLOGY - Product Evaluation                   ║'));
    console.log(chalk_1.default.cyan('╚════════════════════════════════════════════════════════════════════╝\n'));
    for (const [key, desc] of Object.entries(TEN_STAR_DESCRIPTIONS)) {
        const name = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        console.log(chalk_1.default.yellow(`${name.padEnd(18)}`) + chalk_1.default.gray(desc));
    }
    console.log(chalk_1.default.gray('\n  Scoring: 1-10 stars per criterion'));
    console.log(chalk_1.default.gray('  Thresholds:'));
    console.log(chalk_1.default.green('    8.0+   → Strong candidate (BUILD)'));
    console.log(chalk_1.default.yellow('    6.0-7.9 → Marginal (CONSIDER)'));
    console.log(chalk_1.default.red('    <6.0   → Weak candidate (DON\'T BUILD)'));
    console.log('');
}
const program = new commander_1.Command();
program
    .name('plan-ceo-review')
    .description('Product strategy with BAT framework')
    .version('1.0.0');
program
    .argument('<feature>', 'Feature name to review')
    .argument('<goal>', 'Goal/objective of the feature')
    .option('-c, --context <text>', 'Additional context about the feature')
    .option('-m, --market-size <size>', 'Market size (small, medium, large)', 'medium')
    .option('-u, --urgency <level>', 'Urgency level (low, medium, high)', 'medium')
    .option('-r, --resources <level>', 'Available resources (limited, moderate, abundant)', 'moderate')
    .option('-o, --output <path>', 'Save review to JSON file')
    .option('--json', 'Output as JSON')
    .option('--frameworks', 'Show BAT and 10-star framework details')
    .action(async (feature, goal, options) => {
    if (options.frameworks) {
        showFrameworks();
        return;
    }
    const input = { feature, goal, context: options.context, marketSize: options.marketSize, urgency: options.urgency, resources: options.resources };
    await runCEOReview(input, { output: options.output, json: options.json });
});
program
    .command('framework')
    .description('Show BAT and 10-star methodology details')
    .action(() => { showFrameworks(); });
program.parse();
//# sourceMappingURL=index.js.map