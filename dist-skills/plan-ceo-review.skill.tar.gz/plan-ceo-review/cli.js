#!/usr/bin/env node
import('./index.js').then(m => m.default?.() || m);
