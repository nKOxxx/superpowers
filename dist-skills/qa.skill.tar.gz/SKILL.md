# /qa - Systematic Testing

QA Lead testing based on code changes.

## Usage

```bash
superpowers qa [options]
```

## Options

- `--mode, -m` - Test mode: targeted (default), smoke, full
- `--coverage, -c` - Generate coverage report
- `--verbose` - Verbose output

## Modes

- **targeted** - Analyze git diff, run only related tests
- **smoke** - Quick validation test suite
- **full** - Complete regression suite

## Examples

```bash
# Run tests for changed files only
superpowers qa

# Full regression with coverage
superpowers qa --mode=full --coverage

# Smoke tests
superpowers qa --mode=smoke --verbose
```

## Supported Frameworks

- Vitest
- Jest
- Mocha
