interface TestFramework {
    name: string;
    configFiles: string[];
    testCommands: {
        targeted: string;
        smoke: string;
        full: string;
        coverage: string;
    };
}
interface TestResult {
    success: boolean;
    output: string;
    coverage?: string;
    duration: number;
}
interface QAMode {
    name: 'targeted' | 'smoke' | 'full';
    description: string;
}
declare function detectFramework(): TestFramework | null;
declare function getGitDiff(): string[];
declare function mapFilesToTests(files: string[], _fw: TestFramework): string[];
declare function runQAMode(mode: 'targeted' | 'smoke' | 'full', options: {
    coverage?: boolean;
}): Promise<void>;
export { runQAMode, detectFramework, getGitDiff, mapFilesToTests };
export type { TestFramework, TestResult, QAMode };
//# sourceMappingURL=index.d.ts.map