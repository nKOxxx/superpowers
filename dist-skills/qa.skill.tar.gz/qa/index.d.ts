export interface QAOptions {
    mode?: 'targeted' | 'smoke' | 'full';
    diff?: string;
    coverage?: boolean;
    parallel?: boolean;
}
export interface TestResult {
    file: string;
    status: 'passed' | 'failed' | 'skipped';
    duration: number;
    error?: string;
}
export declare class QASkill {
    private framework;
    detectFramework(): Promise<string>;
    run(options?: QAOptions): Promise<{
        results: TestResult[];
        summary: string;
    }>;
    private getTargetedTests;
    private getSmokeTests;
    private getAllTests;
    private glob;
    private executeTests;
    private generateSummary;
}
export default QASkill;
//# sourceMappingURL=index.d.ts.map