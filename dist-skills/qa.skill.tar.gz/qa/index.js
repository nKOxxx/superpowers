"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.QASkill = void 0;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
class QASkill {
    framework = 'unknown';
    async detectFramework() {
        try {
            await fs.access('node_modules/vitest');
            this.framework = 'vitest';
            return 'vitest';
        }
        catch { }
        try {
            await fs.access('node_modules/jest');
            this.framework = 'jest';
            return 'jest';
        }
        catch { }
        try {
            await fs.access('node_modules/mocha');
            this.framework = 'mocha';
            return 'mocha';
        }
        catch { }
        // Check package.json
        try {
            const pkg = JSON.parse(await fs.readFile('package.json', 'utf-8'));
            if (pkg.devDependencies?.vitest || pkg.dependencies?.vitest)
                return 'vitest';
            if (pkg.devDependencies?.jest || pkg.dependencies?.jest)
                return 'jest';
            if (pkg.devDependencies?.mocha || pkg.dependencies?.mocha)
                return 'mocha';
        }
        catch { }
        return 'unknown';
    }
    async run(options = {}) {
        const mode = options.mode || 'targeted';
        const framework = await this.detectFramework();
        if (framework === 'unknown') {
            throw new Error('No test framework detected. Please install vitest, jest, or mocha.');
        }
        let testFiles = [];
        switch (mode) {
            case 'targeted':
                testFiles = await this.getTargetedTests(options.diff || 'HEAD~1');
                break;
            case 'smoke':
                testFiles = await this.getSmokeTests();
                break;
            case 'full':
                testFiles = await this.getAllTests();
                break;
        }
        if (testFiles.length === 0 && mode === 'targeted') {
            return {
                results: [],
                summary: 'No test files affected by changes.'
            };
        }
        const results = await this.executeTests(testFiles, framework, options);
        const summary = this.generateSummary(results, mode);
        return { results, summary };
    }
    async getTargetedTests(diffRange) {
        try {
            const diffOutput = (0, child_process_1.execSync)(`git diff --name-only ${diffRange}`, { encoding: 'utf-8' });
            const changedFiles = diffOutput.trim().split('\n').filter(f => f);
            const testFiles = [];
            for (const file of changedFiles) {
                // Map source files to test files
                if (file.startsWith('src/') || file.startsWith('lib/')) {
                    const possibleTests = [
                        file.replace(/\.(ts|js|tsx|jsx)$/, '.test.$1'),
                        file.replace(/\.(ts|js|tsx|jsx)$/, '.spec.$1'),
                        `tests/${path.basename(file).replace(/\.(ts|js|tsx|jsx)$/, '.test.$1')}`,
                        `test/${path.basename(file).replace(/\.(ts|js|tsx|jsx)$/, '.test.$1')}`
                    ];
                    for (const testFile of possibleTests) {
                        try {
                            await fs.access(testFile);
                            testFiles.push(testFile);
                        }
                        catch { }
                    }
                }
                // Include directly modified test files
                if (file.includes('.test.') || file.includes('.spec.')) {
                    testFiles.push(file);
                }
            }
            return [...new Set(testFiles)];
        }
        catch (error) {
            console.warn('Could not get git diff, running all tests');
            return this.getAllTests();
        }
    }
    async getSmokeTests() {
        const allTests = await this.getAllTests();
        // Filter for smoke tests by looking for 'smoke' in filename or content
        const smokeTests = [];
        for (const test of allTests) {
            if (test.toLowerCase().includes('smoke')) {
                smokeTests.push(test);
                continue;
            }
            try {
                const content = await fs.readFile(test, 'utf-8');
                if (content.toLowerCase().includes('smoke') ||
                    content.toLowerCase().includes('@critical') ||
                    content.toLowerCase().includes('describe(\'basic') ||
                    content.toLowerCase().includes('describe(\"basic')) {
                    smokeTests.push(test);
                }
            }
            catch { }
        }
        return smokeTests.length > 0 ? smokeTests : allTests.slice(0, 3);
    }
    async getAllTests() {
        const patterns = [
            '**/*.test.ts',
            '**/*.test.js',
            '**/*.test.tsx',
            '**/*.test.jsx',
            '**/*.spec.ts',
            '**/*.spec.js'
        ];
        const tests = [];
        for (const pattern of patterns) {
            try {
                const files = await this.glob(pattern);
                tests.push(...files);
            }
            catch { }
        }
        return [...new Set(tests)];
    }
    async glob(pattern) {
        const { glob } = await import('glob');
        return glob(pattern, { ignore: ['node_modules/**'] });
    }
    async executeTests(testFiles, framework, options) {
        const results = [];
        try {
            let command = '';
            switch (framework) {
                case 'vitest':
                    command = `npx vitest run ${testFiles.join(' ')}`;
                    if (options.coverage)
                        command += ' --coverage';
                    break;
                case 'jest':
                    command = `npx jest ${testFiles.join(' ')}`;
                    if (options.coverage)
                        command += ' --coverage';
                    if (options.parallel)
                        command += ' --maxWorkers=4';
                    break;
                case 'mocha':
                    command = `npx mocha ${testFiles.join(' ')}`;
                    break;
            }
            const startTime = Date.now();
            (0, child_process_1.execSync)(command, {
                encoding: 'utf-8',
                stdio: 'pipe'
            });
            // If we get here, all tests passed
            for (const file of testFiles) {
                results.push({
                    file,
                    status: 'passed',
                    duration: Date.now() - startTime
                });
            }
        }
        catch (error) {
            // Parse test failures from output
            const output = error.stdout || error.message || '';
            for (const file of testFiles) {
                const filePattern = new RegExp(file.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
                const hasError = filePattern.test(output) || output.includes('FAIL');
                results.push({
                    file,
                    status: hasError ? 'failed' : 'passed',
                    duration: 0,
                    error: hasError ? output : undefined
                });
            }
        }
        return results;
    }
    generateSummary(results, mode) {
        const passed = results.filter(r => r.status === 'passed').length;
        const failed = results.filter(r => r.status === 'failed').length;
        const skipped = results.filter(r => r.status === 'skipped').length;
        const total = results.length;
        return `
══════════════════════════════════════════════════
QA Mode: ${mode.toUpperCase()}
══════════════════════════════════════════════════

Tests Run: ${total}
  ✓ Passed: ${passed}
  ✗ Failed: ${failed}
  ○ Skipped: ${skipped}

Status: ${failed === 0 ? 'PASSED ✓' : 'FAILED ✗'}
`;
    }
}
exports.QASkill = QASkill;
exports.default = QASkill;
//# sourceMappingURL=index.js.map