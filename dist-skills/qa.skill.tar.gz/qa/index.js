"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runQAMode = runQAMode;
exports.detectFramework = detectFramework;
exports.getGitDiff = getGitDiff;
exports.mapFilesToTests = mapFilesToTests;
const commander_1 = require("commander");
const chalk_1 = __importDefault(require("chalk"));
const ora_1 = __importDefault(require("ora"));
const child_process_1 = require("child_process");
const fs_1 = require("fs");
const path_1 = require("path");
const TEST_FRAMEWORKS = [
    {
        name: 'vitest',
        configFiles: ['vitest.config.ts', 'vitest.config.js', 'vitest.config.mjs'],
        testCommands: {
            targeted: 'npx vitest run --reporter=verbose',
            smoke: 'npx vitest run --reporter=verbose --testNamePattern="smoke"',
            full: 'npx vitest run --reporter=verbose',
            coverage: 'npx vitest run --coverage --reporter=verbose'
        }
    },
    {
        name: 'jest',
        configFiles: ['jest.config.ts', 'jest.config.js', 'jest.config.mjs', 'package.json'],
        testCommands: {
            targeted: 'npx jest --verbose',
            smoke: 'npx jest --verbose --testNamePattern="smoke"',
            full: 'npx jest --verbose',
            coverage: 'npx jest --coverage --verbose'
        }
    },
    {
        name: 'mocha',
        configFiles: ['.mocharc.json', '.mocharc.js', 'package.json'],
        testCommands: {
            targeted: 'npx mocha --reporter spec',
            smoke: 'npx mocha --reporter spec --grep "smoke"',
            full: 'npx mocha --reporter spec',
            coverage: 'npx c8 npx mocha --reporter spec'
        }
    }
];
const QA_MODES = [
    { name: 'targeted', description: 'Analyze git diff and run relevant tests' },
    { name: 'smoke', description: 'Quick validation smoke tests' },
    { name: 'full', description: 'Complete regression test suite' }
];
function detectFramework() {
    for (const fw of TEST_FRAMEWORKS) {
        for (const configFile of fw.configFiles) {
            if ((0, fs_1.existsSync)((0, path_1.join)(process.cwd(), configFile))) {
                // For package.json, check if it has the framework
                if (configFile === 'package.json') {
                    const pkg = JSON.parse((0, fs_1.readFileSync)((0, path_1.join)(process.cwd(), configFile), 'utf-8'));
                    if (pkg.devDependencies?.[fw.name] || pkg.dependencies?.[fw.name]) {
                        return fw;
                    }
                }
                else {
                    return fw;
                }
            }
        }
    }
    return null;
}
function getGitDiff() {
    try {
        const diffOutput = (0, child_process_1.execSync)('git diff HEAD~1 --name-only', { encoding: 'utf-8', cwd: process.cwd() });
        return diffOutput.trim().split('\n').filter(f => f.length > 0);
    }
    catch {
        try {
            const diffOutput = (0, child_process_1.execSync)('git diff --name-only', { encoding: 'utf-8', cwd: process.cwd() });
            return diffOutput.trim().split('\n').filter(f => f.length > 0);
        }
        catch {
            return [];
        }
    }
}
function mapFilesToTests(files, _fw) {
    const testFiles = [];
    for (const file of files) {
        // Skip test files themselves
        if (file.includes('.test.') || file.includes('.spec.')) {
            continue;
        }
        // Map source files to their test counterparts
        const extensions = ['.test.ts', '.test.js', '.spec.ts', '.spec.js'];
        const basePath = file
            .replace(/^src\//, '')
            .replace(/\.[^.]+$/, '');
        for (const ext of extensions) {
            const possibleTests = [
                `${basePath}${ext}`,
                `test/${basePath}${ext}`,
                `tests/${basePath}${ext}`,
                `__tests__/${basePath}${ext}`,
                file.replace(/\.[^.]+$/, ext)
            ];
            for (const testPath of possibleTests) {
                if ((0, fs_1.existsSync)((0, path_1.join)(process.cwd(), testPath))) {
                    testFiles.push(testPath);
                    break;
                }
            }
        }
    }
    return [...new Set(testFiles)];
}
function runTests(command, cwd) {
    const startTime = Date.now();
    try {
        const output = (0, child_process_1.execSync)(command, {
            encoding: 'utf-8',
            cwd,
            stdio: 'pipe'
        });
        return {
            success: true,
            output,
            duration: Date.now() - startTime
        };
    }
    catch (error) {
        return {
            success: false,
            output: error.stdout || error.message,
            duration: Date.now() - startTime
        };
    }
}
function formatDuration(ms) {
    if (ms < 1000)
        return `${ms}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
}
async function runQAMode(mode, options) {
    const spinner = (0, ora_1.default)(`Running QA mode: ${mode}...`).start();
    try {
        // Detect test framework
        const fw = detectFramework();
        if (!fw) {
            spinner.fail(chalk_1.default.red('No test framework detected. Supported: vitest, jest, mocha'));
            process.exit(1);
        }
        spinner.text = `Detected framework: ${chalk_1.default.cyan(fw.name)}`;
        let command;
        if (mode === 'targeted') {
            const changedFiles = getGitDiff();
            if (changedFiles.length === 0) {
                spinner.warn(chalk_1.default.yellow('No git changes detected. Running full test suite instead.'));
                command = fw.testCommands.full;
            }
            else {
                spinner.text = `Analyzing ${changedFiles.length} changed files...`;
                const testFiles = mapFilesToTests(changedFiles, fw);
                if (testFiles.length === 0) {
                    spinner.warn(chalk_1.default.yellow('No related test files found. Running full test suite.'));
                    command = fw.testCommands.full;
                }
                else {
                    spinner.text = `Found ${testFiles.length} related test files`;
                    console.log(chalk_1.default.gray('\n  Changed files:'));
                    changedFiles.slice(0, 5).forEach(f => console.log(chalk_1.default.gray(`    - ${f}`)));
                    if (changedFiles.length > 5) {
                        console.log(chalk_1.default.gray(`    ... and ${changedFiles.length - 5} more`));
                    }
                    console.log(chalk_1.default.gray('\n  Mapped test files:'));
                    testFiles.forEach(f => console.log(chalk_1.default.gray(`    - ${f}`)));
                    // Run specific test files
                    const testPattern = testFiles.join(' ');
                    command = `${fw.testCommands.targeted} ${testPattern}`;
                }
            }
        }
        else if (mode === 'smoke') {
            command = fw.testCommands.smoke;
        }
        else {
            command = fw.testCommands.full;
        }
        if (options.coverage) {
            command = fw.testCommands.coverage;
        }
        spinner.text = 'Running tests...';
        const result = runTests(command, process.cwd());
        spinner.stop();
        // Print results
        console.log('\n' + chalk_1.default.cyan('═'.repeat(60)));
        console.log(chalk_1.default.bold(`  QA Test Results: ${mode.toUpperCase()} Mode`));
        console.log(chalk_1.default.cyan('═'.repeat(60)));
        if (result.success) {
            console.log(chalk_1.default.green(`\n  ✓ All tests passed`));
        }
        else {
            console.log(chalk_1.default.red(`\n  ✗ Tests failed`));
        }
        console.log(chalk_1.default.gray(`  Duration: ${formatDuration(result.duration)}`));
        console.log(chalk_1.default.gray(`  Framework: ${fw.name}`));
        // Extract test counts from output
        const testMatch = result.output.match(/(\d+)\s+passing|Tests:\s+(\d+)\s+passed/);
        const failMatch = result.output.match(/(\d+)\s+failing|Tests:\s+.*?(\d+)\s+failed/);
        if (testMatch) {
            console.log(chalk_1.default.green(`  Passing: ${testMatch[1] || testMatch[2]}`));
        }
        if (failMatch) {
            console.log(chalk_1.default.red(`  Failing: ${failMatch[1] || failMatch[2]}`));
        }
        console.log(chalk_1.default.cyan('\n─'.repeat(60)));
        console.log(chalk_1.default.gray(result.output));
        console.log(chalk_1.default.cyan('─'.repeat(60) + '\n'));
        if (!result.success) {
            process.exit(1);
        }
    }
    catch (error) {
        spinner.fail(chalk_1.default.red(`QA run failed: ${error instanceof Error ? error.message : 'Unknown error'}`));
        process.exit(1);
    }
}
const program = new commander_1.Command();
program
    .name('qa')
    .description('Systematic testing as QA Lead')
    .version('1.0.0');
program
    .option('-m, --mode <mode>', 'Test mode: targeted, smoke, full', 'targeted')
    .option('-c, --coverage', 'Enable coverage reporting')
    .option('--list-frameworks', 'List detected test frameworks')
    .action(async (options) => {
    if (options.listFrameworks) {
        const fw = detectFramework();
        console.log(chalk_1.default.cyan('Detected Test Framework:'));
        if (fw) {
            console.log(`  ${chalk_1.default.green('✓')} ${fw.name}`);
        }
        else {
            console.log(`  ${chalk_1.default.red('✗')} None detected`);
            console.log(chalk_1.default.gray('  Supported: vitest, jest, mocha'));
        }
        return;
    }
    const mode = options.mode;
    if (!QA_MODES.find(m => m.name === mode)) {
        console.error(chalk_1.default.red(`Invalid mode: ${mode}`));
        console.log(chalk_1.default.gray(`Valid modes: ${QA_MODES.map(m => m.name).join(', ')}`));
        process.exit(1);
    }
    await runQAMode(mode, { coverage: options.coverage });
});
program
    .command('targeted')
    .description('Run targeted tests based on git diff')
    .option('-c, --coverage', 'Enable coverage reporting')
    .action(async (options) => {
    await runQAMode('targeted', { coverage: options.coverage });
});
program
    .command('smoke')
    .description('Run smoke tests')
    .option('-c, --coverage', 'Enable coverage reporting')
    .action(async (options) => {
    await runQAMode('smoke', { coverage: options.coverage });
});
program
    .command('full')
    .description('Run full regression test suite')
    .option('-c, --coverage', 'Enable coverage reporting')
    .action(async (options) => {
    await runQAMode('full', { coverage: options.coverage });
});
program
    .command('modes')
    .description('Show available QA modes')
    .action(() => {
    console.log(chalk_1.default.cyan('Available QA Modes:'));
    console.log('');
    for (const mode of QA_MODES) {
        console.log(`  ${chalk_1.default.yellow(mode.name.padEnd(12))} ${mode.description}`);
    }
});
// Run if called directly
if (require.main === module) {
    program.parse();
}
//# sourceMappingURL=index.js.map