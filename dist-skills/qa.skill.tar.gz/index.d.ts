export interface QAOptions {
    mode?: 'targeted' | 'smoke' | 'full';
    framework?: 'vitest' | 'jest' | 'mocha' | 'auto';
    coverage?: boolean;
    watch?: boolean;
    files?: string[];
    changed?: boolean;
    failFast?: boolean;
}
export interface TestFramework {
    name: string;
    configFiles: string[];
    testPatterns: string[];
    runCommand: string;
    coverageFlag: string;
    watchFlag: string;
}
export interface QAResult {
    framework: string;
    mode: string;
    command: string;
    exitCode: number;
    output: string;
    error?: string;
    summary?: {
        passed: number;
        failed: number;
        skipped: number;
        duration: number;
    };
}
export declare function qa(options?: QAOptions): Promise<QAResult>;
//# sourceMappingURL=index.d.ts.map