# /browse - Browser Automation

Screenshot capture and browser automation with Playwright.

## Usage

```bash
superpowers browse <url> [options]
```

## Options

- `--viewport, -v` - Viewport preset (mobile|tablet|desktop) or WxH format
- `--fullPage, -f` - Capture full page screenshot
- `--selector, -s` - Screenshot specific CSS element
- `--actions, -a` - JSON array of actions to perform
- `--output, -o` - Output file path
- `--base64` - Output as base64 for Telegram

## Action Format

Actions are JSON arrays:
```json
[
  {"type": "click", "selector": "#button"},
  {"type": "type", "selector": "#input", "text": "hello"},
  {"type": "wait", "delay": 1000},
  {"type": "scroll"},
  {"type": "hover", "selector": "#tooltip"},
  {"type": "press", "key": "Enter"}
]
```

## Examples

```bash
# Mobile screenshot
superpowers browse https://example.com --viewport=mobile

# Screenshot with actions
superpowers browse https://example.com --actions='[{"type":"click","selector":"#menu"}]'

# Element screenshot to Telegram
superpowers browse https://example.com --selector=".hero" --base64
```
