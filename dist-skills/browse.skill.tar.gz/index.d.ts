/**
 * Browse options
 */
export interface BrowseOptions {
    viewport: string;
    width?: string;
    height?: string;
    fullPage: boolean;
    selector?: string;
    output?: string;
    wait: string;
    actions?: string;
}
/**
 * Browse action definition
 */
export interface BrowseAction {
    type: 'click' | 'type' | 'wait' | 'scroll' | 'hover' | 'press' | 'select';
    selector?: string;
    text?: string;
    duration?: number;
    x?: number;
    y?: number;
    key?: string;
    value?: string;
}
/**
 * Viewport presets
 */
export declare const viewportPresets: Record<string, {
    width: number;
    height: number;
    deviceScaleFactor?: number;
}>;
/**
 * Main browse command
 */
export declare function browseCommand(url: string, options: BrowseOptions): Promise<void>;
//# sourceMappingURL=index.d.ts.map