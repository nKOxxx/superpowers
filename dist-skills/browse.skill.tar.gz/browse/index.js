"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const commander_1 = require("commander");
const chalk_1 = __importDefault(require("chalk"));
const ora_1 = __importDefault(require("ora"));
const playwright_1 = require("playwright");
const fs_1 = require("fs");
const VIEWPORT_PRESETS = {
    mobile: { width: 375, height: 667 },
    tablet: { width: 768, height: 1024 },
    desktop: { width: 1920, height: 1080 }
};
async function captureScreenshot(options) {
    const spinner = (0, ora_1.default)('Launching browser...').start();
    let browser = null;
    let context = null;
    let page = null;
    try {
        browser = await playwright_1.chromium.launch({ headless: true });
        const viewport = VIEWPORT_PRESETS[options.viewport || 'desktop'] || VIEWPORT_PRESETS.desktop;
        context = await browser.newContext({ viewport, userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' });
        page = await context.newPage();
        spinner.text = `Navigating to ${options.url}...`;
        await page.goto(options.url, { waitUntil: 'networkidle', timeout: 30000 });
        if (options.flow) {
            spinner.text = 'Executing flow...';
            const flowConfig = JSON.parse((0, fs_1.readFileSync)(options.flow, 'utf-8'));
            for (const action of flowConfig.actions)
                await executeAction(page, action);
        }
        spinner.text = 'Capturing screenshot...';
        let screenshotBuffer;
        if (options.selector) {
            const element = await page.locator(options.selector).first();
            screenshotBuffer = await element.screenshot({ type: 'png' });
        }
        else {
            screenshotBuffer = await page.screenshot({ fullPage: options.fullPage || false, type: 'png' });
        }
        const base64Image = screenshotBuffer.toString('base64');
        spinner.succeed(chalk_1.default.green('Screenshot captured!'));
        return base64Image;
    }
    catch (error) {
        spinner.fail(chalk_1.default.red(`Failed: ${error instanceof Error ? error.message : 'Unknown error'}`));
        throw error;
    }
    finally {
        if (page)
            await page.close();
        if (context)
            await context.close();
        if (browser)
            await browser.close();
    }
}
async function executeAction(page, action) {
    switch (action.type) {
        case 'click':
            if (action.selector)
                await page.click(action.selector);
            else if (action.x !== undefined && action.y !== undefined)
                await page.mouse.click(action.x, action.y);
            break;
        case 'type':
            if (action.selector && action.text !== undefined)
                await page.fill(action.selector, action.text);
            break;
        case 'wait':
            await page.waitForTimeout(action.delay || 1000);
            break;
        case 'scroll':
            if (action.x !== undefined && action.y !== undefined)
                await page.evaluate(({ x, y }) => window.scrollTo(x, y), { x: action.x, y: action.y });
            else
                await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
            break;
        case 'hover':
            if (action.selector)
                await page.hover(action.selector);
            break;
    }
}
function validateUrl(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://'))
        return `https://${url}`;
    return url;
}
const program = new commander_1.Command();
program.name('browse').description('Browser automation with Playwright').version('1.0.0');
program.argument('<url>', 'URL to capture').option('-v, --viewport <preset>', 'Viewport (mobile, tablet, desktop)', 'desktop')
    .option('-f, --full-page', 'Full page screenshot').option('-s, --selector <selector>', 'Element selector')
    .option('--flow <path>', 'Flow config JSON').action(async (url, options) => {
    try {
        const base64Image = await captureScreenshot({ url: validateUrl(url), viewport: options.viewport, fullPage: options.fullPage, selector: options.selector, flow: options.flow });
        console.log(`\n${chalk_1.default.cyan('=== BASE64 ===')}\n${base64Image}\n${chalk_1.default.cyan('=== END ===')}\n`);
    }
    catch {
        process.exit(1);
    }
});
program.command('flow').description('Execute flow test').argument('<config>', 'Config path').action(async (configPath) => {
    try {
        const flowConfig = JSON.parse((0, fs_1.readFileSync)(configPath, 'utf-8'));
        const base64Image = await captureScreenshot({ url: validateUrl(flowConfig.url), viewport: flowConfig.viewport, flow: configPath });
        console.log(`\n${chalk_1.default.cyan('=== BASE64 ===')}\n${base64Image}\n${chalk_1.default.cyan('=== END ===')}\n`);
    }
    catch {
        process.exit(1);
    }
});
program.command('presets').description('Show viewport presets').action(() => {
    console.log(chalk_1.default.cyan('Viewport Presets:'));
    for (const [name, dim] of Object.entries(VIEWPORT_PRESETS))
        console.log(`  ${chalk_1.default.yellow(name)} ${dim.width}x${dim.height}`);
});
program.parse();
//# sourceMappingURL=index.js.map