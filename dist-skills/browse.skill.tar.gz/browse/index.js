"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserSkill = void 0;
const playwright_1 = require("playwright");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const VIEWPORT_PRESETS = {
    mobile: { width: 375, height: 667 },
    tablet: { width: 768, height: 1024 },
    desktop: { width: 1280, height: 720 }
};
class BrowserSkill {
    browser = null;
    async init() {
        this.browser = await playwright_1.chromium.launch({ headless: true });
    }
    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
    async screenshot(options) {
        if (!this.browser) {
            await this.init();
        }
        const screenshots = [];
        const page = await this.browser.newPage();
        try {
            // Set viewport
            const viewport = this.resolveViewport(options.viewport);
            await page.setViewportSize(viewport);
            // Navigate
            await page.goto(options.url, {
                waitUntil: 'networkidle',
                timeout: options.timeout || 30000
            });
            // Wait for element if specified
            if (options.waitFor) {
                await page.waitForSelector(options.waitFor, { timeout: 10000 });
            }
            // Execute actions if provided
            if (options.actions) {
                await this.executeActions(page, options.actions, screenshots, options);
            }
            else {
                // Single screenshot
                const screenshotPath = await this.takeScreenshot(page, options);
                screenshots.push(screenshotPath);
            }
            return screenshots;
        }
        finally {
            await page.close();
        }
    }
    resolveViewport(viewport) {
        if (!viewport)
            return VIEWPORT_PRESETS.desktop;
        if (typeof viewport === 'string') {
            return VIEWPORT_PRESETS[viewport] || VIEWPORT_PRESETS.desktop;
        }
        return viewport;
    }
    async takeScreenshot(page, options) {
        const outputDir = options.output || './screenshots';
        await fs.mkdir(outputDir, { recursive: true });
        const url = new URL(options.url);
        const hostname = url.hostname.replace(/[^a-zA-Z0-9]/g, '_');
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `${hostname}_${timestamp}.png`;
        const filepath = path.join(outputDir, filename);
        await page.screenshot({
            path: filepath,
            fullPage: options.fullPage || false
        });
        return filepath;
    }
    async executeActions(page, actionsStr, screenshots, options) {
        const actions = actionsStr.split(',').map(a => a.trim());
        for (const action of actions) {
            const [type, ...params] = action.split(':');
            switch (type) {
                case 'click':
                    if (params[0]) {
                        await page.click(params[0]);
                    }
                    break;
                case 'type':
                    if (params[0] && params[1]) {
                        await page.fill(params[0], params[1]);
                    }
                    break;
                case 'wait':
                    if (params[0]) {
                        const delay = parseInt(params[0], 10);
                        await page.waitForTimeout(delay);
                    }
                    break;
                case 'scroll':
                    await page.evaluate('window.scrollBy(0, window.innerHeight)');
                    break;
                case 'hover':
                    if (params[0]) {
                        await page.hover(params[0]);
                    }
                    break;
                case 'screenshot':
                    const screenshotPath = await this.takeScreenshot(page, options);
                    screenshots.push(screenshotPath);
                    break;
            }
        }
    }
    async captureBase64(options) {
        if (!this.browser) {
            await this.init();
        }
        const page = await this.browser.newPage();
        try {
            const viewport = this.resolveViewport(options.viewport);
            await page.setViewportSize(viewport);
            await page.goto(options.url, {
                waitUntil: 'networkidle',
                timeout: options.timeout || 30000
            });
            if (options.waitFor) {
                await page.waitForSelector(options.waitFor, { timeout: 10000 });
            }
            const screenshot = await page.screenshot({
                fullPage: options.fullPage || false,
                type: 'png'
            });
            return screenshot.toString('base64');
        }
        finally {
            await page.close();
        }
    }
}
exports.BrowserSkill = BrowserSkill;
exports.default = BrowserSkill;
//# sourceMappingURL=index.js.map