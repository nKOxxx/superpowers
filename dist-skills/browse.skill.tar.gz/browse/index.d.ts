export interface BrowseOptions {
    url: string;
    viewport?: 'mobile' | 'tablet' | 'desktop' | {
        width: number;
        height: number;
    };
    fullPage?: boolean;
    output?: string;
    waitFor?: string;
    actions?: string;
    timeout?: number;
}
export declare class BrowserSkill {
    private browser;
    init(): Promise<void>;
    close(): Promise<void>;
    screenshot(options: BrowseOptions): Promise<string[]>;
    private resolveViewport;
    private takeScreenshot;
    private executeActions;
    captureBase64(options: BrowseOptions): Promise<string>;
}
export default BrowserSkill;
//# sourceMappingURL=index.d.ts.map